<?php

/**
 * Provide a admin footer view for the plugin
 *
 * @link       http://www.webfactoryltd.com
 * @since      0.1
 */

?>

	</div><!-- .signals-fix-wp38 -->
</div><!-- .signals-cnt-fix -->
