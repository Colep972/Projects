<?php
$themes =
array (
  0 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Thu, 22 Feb 2018 18:45:00 +0000',
    'name' => 'Aeroplane Company',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'aeroplane-company',
  ),
  1 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sun, 09 Sep 2018 16:06:39 +0000',
    'name' => 'Air Balloon',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'air-balloon',
  ),
  2 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:43:04 +0000',
    'name' => 'Animated Clock',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'animated-clock',
  ),
  3 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sat, 08 Sep 2018 14:42:03 +0000',
    'name' => 'Architecture',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'architecture',
  ),
  4 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sun, 23 Sep 2018 12:44:52 +0000',
    'name' => 'Auto Service',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'auto-service',
  ),
  5 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sat, 09 Jun 2018 13:26:02 +0000',
    'name' => 'Beach',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'beach',
  ),
  6 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.05',
    'last_edit' => 'Wed, 28 Feb 2018 10:30:46 +0000',
    'name' => 'Bicycle Race',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'bicycle-race',
  ),
  7 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Sat, 24 Feb 2018 11:48:50 +0000',
    'name' => 'Bitcoin Miners',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'bitcoin-miners',
  ),
  8 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:50:26 +0000',
    'name' => 'Blogging',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'blogging',
  ),
  9 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Tue, 27 Feb 2018 09:56:05 +0000',
    'name' => 'Book Lovers',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'book-lovers',
  ),
  10 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.001',
    'last_edit' => 'Thu, 15 Feb 2018 16:24:58 +0000',
    'name' => 'Business Company',
    'description' => '',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'business-company',
  ),
  11 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:06:41 +0000',
    'name' => 'Business',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'business',
  ),
  12 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sun, 29 Jul 2018 12:52:06 +0000',
    'name' => 'Cityscape',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'cityscape',
  ),
  13 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.14',
    'last_edit' => 'Fri, 23 Mar 2018 16:46:05 +0000',
    'name' => 'Clouds Screensaver (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'clouds-screensaver-video',
  ),
  14 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Thu, 22 Feb 2018 18:45:40 +0000',
    'name' => 'Coffee Shop',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'coffee-shop',
  ),
  15 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 04 May 2018 08:57:40 +0000',
    'name' => 'Cold Lake',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'cold-lake',
  ),
  16 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 20:41:31 +0000',
    'name' => 'Default',
    'description' => 'Default settings, nothing more.',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'default',
  ),
  17 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:24:59 +0000',
    'name' => 'Dental Clinic',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'dental-clinic',
  ),
  18 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.001',
    'last_edit' => 'Tue, 20 Feb 2018 09:14:59 +0000',
    'name' => 'Dog Training and Behavior Consulting',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'dog-training-and-behavior-consulting',
  ),
  19 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 29 Aug 2018 16:00:04 +0000',
    'name' => 'Fall (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'fall-video',
  ),
  20 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sat, 21 Jul 2018 22:37:09 +0000',
    'name' => 'Fashion',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'fashion',
  ),
  21 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:33:55 +0000',
    'name' => 'Flower Shop',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'flower-shop',
  ),
  22 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 02 May 2018 09:37:48 +0000',
    'name' => 'Food Blog',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'food-blog',
  ),
  23 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Mon, 18 Jun 2018 16:40:10 +0000',
    'name' => 'Football',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'football',
  ),
  24 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sat, 28 Jul 2018 15:16:26 +0000',
    'name' => 'Holiday Resort',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'holiday-resort',
  ),
  25 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:26:42 +0000',
    'name' => 'Homemade Chocolate Gifts',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'homemade-chocolate-gifts',
  ),
  26 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:59:44 +0000',
    'name' => 'Interior Design',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'interior-design',
  ),
  27 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.14',
    'last_edit' => 'Fri, 23 Mar 2018 16:42:15 +0000',
    'name' => 'Journey (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'journey-video',
  ),
  28 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:28:28 +0000',
    'name' => 'LEGO Bricks',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'lego-bricks',
  ),
  29 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 29 Aug 2018 16:36:44 +0000',
    'name' => 'Loneliness',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'loneliness',
  ),
  30 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:04:55 +0000',
    'name' => 'Lonely Road',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'lonely-road',
  ),
  31 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:30:37 +0000',
    'name' => 'Luxury Car',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'luxury-car',
  ),
  32 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 18:31:18 +0000',
    'name' => 'Maintenance Mode',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'maintenance-mode',
  ),
  33 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 17:59:30 +0000',
    'name' => 'Makeup Artist Training',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'makeup-artist-training',
  ),
  34 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sun, 23 Sep 2018 13:09:03 +0000',
    'name' => 'Misty Forest (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'misty-forest-video',
  ),
  35 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:08:31 +0000',
    'name' => 'Mobile Designer',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'mobile-designer',
  ),
  36 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 18:04:32 +0000',
    'name' => 'Modern Blog',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'modern-blog',
  ),
  37 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 10:14:21 +0000',
    'name' => 'Modern Office',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'modern-office',
  ),
  38 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:48:23 +0000',
    'name' => 'Mountain Slide',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'mountain-slide',
  ),
  39 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.05',
    'last_edit' => 'Thu, 01 Mar 2018 10:49:52 +0000',
    'name' => 'Mountain',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'mountain',
  ),
  40 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:12:56 +0000',
    'name' => 'Movie Trailer (Video)',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'movie-trailer-video',
  ),
  41 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 10:17:02 +0000',
    'name' => 'Nature',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'nature',
  ),
  42 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.14',
    'last_edit' => 'Fri, 23 Mar 2018 16:37:55 +0000',
    'name' => 'Office Meeting (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'office-meeting-video',
  ),
  43 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:35:44 +0000',
    'name' => 'Office Theme',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'office-theme',
  ),
  44 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 18:07:28 +0000',
    'name' => 'Online Learning',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'online-learning',
  ),
  45 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:10:44 +0000',
    'name' => 'Pancake House',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'pancake-house',
  ),
  46 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:15:19 +0000',
    'name' => 'Parenting',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'parenting',
  ),
  47 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Tue, 28 Aug 2018 15:03:08 +0000',
    'name' => 'Passage',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'passage',
  ),
  48 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:35:07 +0000',
    'name' => 'Photography',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'photography',
  ),
  49 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:41:09 +0000',
    'name' => 'Running Blog',
    'description' => '',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'running-blog',
  ),
  50 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.14',
    'last_edit' => 'Sat, 24 Mar 2018 10:23:40 +0000',
    'name' => 'Running (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'running-video',
  ),
  51 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 11:17:32 +0000',
    'name' => 'Shoes Store',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'shoes-store',
  ),
  52 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:17:21 +0000',
    'name' => 'Simple Beige Design',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'simple-beige-design',
  ),
  53 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:19:34 +0000',
    'name' => 'Snow Screensaver (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'snow-screensaver-video',
  ),
  54 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 11:44:39 +0000',
    'name' => 'Snowboarding Blog',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'snowboarding-blog',
  ),
  55 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:21:19 +0000',
    'name' => 'Snowy Mountain',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'snowy-mountain',
  ),
  56 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Fri, 30 Mar 2018 09:59:40 +0000',
    'name' => 'Spring',
    'description' => '',
    'frontpage' => '0',
    'status' => 'agency',
    'name_clean' => 'spring',
  ),
  57 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sun, 19 Aug 2018 07:48:14 +0000',
    'name' => 'Stylish Workplace',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'stylish-workplace',
  ),
  58 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:22:49 +0000',
    'name' => 'The Big City Newsletter',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'the-big-city-newsletter',
  ),
  59 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.14',
    'last_edit' => 'Thu, 22 Mar 2018 11:33:57 +0000',
    'name' => 'The Sunny View',
    'description' => 'Andrea',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'the-sunny-view',
  ),
  60 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.001',
    'last_edit' => 'Tue, 20 Feb 2018 10:57:27 +0000',
    'name' => 'Travel Agency',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'travel-agency',
  ),
  61 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:39:22 +0000',
    'name' => 'Travel Blog',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'travel-blog',
  ),
  62 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:24:56 +0000',
    'name' => 'Tulips',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'tulips',
  ),
  63 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.001',
    'last_edit' => 'Mon, 19 Feb 2018 12:31:48 +0000',
    'name' => 'Video Production',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'video-production',
  ),
  64 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Sat, 07 Jul 2018 15:15:19 +0000',
    'name' => 'Walking Away (Video)',
    'description' => '',
    'frontpage' => '0',
    'status' => 'pro',
    'name_clean' => 'walking-away-video',
  ),
  65 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Mon, 26 Feb 2018 19:54:07 +0000',
    'name' => 'Webinar',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'webinar',
  ),
  66 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.005',
    'last_edit' => 'Fri, 23 Feb 2018 11:53:23 +0000',
    'name' => 'Wedding Blog',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'wedding-blog',
  ),
  67 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Tue, 22 May 2018 12:41:04 +0000',
    'name' => 'White Orchids',
    'description' => '',
    'frontpage' => '1',
    'status' => 'pro',
    'name_clean' => 'white-orchids',
  ),
  68 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '5.14',
    'last_edit' => 'Thu, 22 Mar 2018 11:29:56 +0000',
    'name' => 'Working Out',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'working-out',
  ),
  69 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.05',
    'last_edit' => 'Fri, 02 Mar 2018 12:36:42 +0000',
    'name' => 'Workplace',
    'description' => 'Andrea',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'workplace',
  ),
  70 =>
  array (
    'type' => 'CSMM PRO',
    'version' => '15.17',
    'last_edit' => 'Wed, 25 Apr 2018 11:00:38 +0000',
    'name' => 'Writing Service (Video)',
    'description' => '',
    'frontpage' => '1',
    'status' => 'agency',
    'name_clean' => 'writing-service-video',
  )
);

array_unshift($themes, array('name' => 'Minimal', 'name_clean' => 'minimal', 'status' => 'free'));
array_unshift($themes, array('name' => 'Default', 'name_clean' => 'default', 'status' => 'free'));
?>

<div class="signals-tile" id="themes">
	<div class="signals-tile-body">
		<div class="signals-tile-title">Themes</div>
    <p>Once a theme is activated it can be fullly adjusted and modified. There are no "locked in" features. Please note that activating a theme overwrites all customizations done to the current design. Non-design settings such as access control are not affected.<br>
<?php
if (csmm_is_mailoptin_active()) {
  echo 'Collecting subscribers and leads is one of the most important aspect of any coming soon page. Choose MailOptin in <a href="#email" class="js-action csmm-change-tab">email options</a> if you want to add popup optins or advanced in-content subscription boxes.';
} else {
  echo 'Collecting subscribers and leads is one of the most important aspect of any coming soon page. To connect to any autoresponder such as Constant Contact or Aweber and to collect leads via an in-content box or a popup install the <a href="#" class="open-mailoptin-upsell">free MailOptin plugin</a>. It\'s fully integrated into our designs and offers numerous options.';
}
?>
</p>

		<div class="signals-section-content">
<?php
  foreach ($themes as $theme) {
    echo '<div class="theme-thumb" data-theme="' . $theme['name_clean'] . '">';
    if ($theme['status'] != 'free') {
      echo '<a href="' . csmm_generate_web_link('preview-theme-thumb-' . $theme['name_clean'], 'theme-preview', array('theme' => $theme['name_clean'])) . '" target="_blank"><img src="' . CSMM_URL . '/framework/admin/img/themes/pro/' . $theme['name_clean'] . '.jpg" alt="Preview ' . $theme['name'] . '" title="Preview ' . $theme['name'] . '"></a>';
    } else {
      echo '<img src="' . CSMM_URL . '/framework/admin/img/themes/' . $theme['name_clean'] . '.jpg" alt="' . $theme['name'] . '" title="' . $theme['name'] . '">';
    }
    echo '<span class="name">' . $theme['name'] . '</span>';
    echo '<span name="actions">';
    if ($theme['status'] != 'free') {
      echo '<a href="#pro" class="signals-btn csmm-change-tab">Get this theme</a>&nbsp; &nbsp;';
      echo '<a target="_blank" class="signals-btn signals-btn-secondary" href="' . csmm_generate_web_link('preview-theme-' . $theme['name_clean'], 'theme-preview', array('theme' => $theme['name_clean'])) . '">Preview</a>';
    } else {
      echo '<a href="' . add_query_arg(array('action' => 'csmm_activate_theme', 'theme' => $theme['name_clean'], 'redirect' => urlencode($_SERVER['REQUEST_URI'])), admin_url('admin.php')) . '" class="signals-btn confirm-action" data-confirm="Are you sure you want to activate the selected theme? Customizations you made on the current design will be lost.">Activate</a>&nbsp; &nbsp;';
    }
    echo '</span>';
    if ($theme['status'] != 'free') {
      echo '<div class="ribbon" title="' . ucfirst($theme['status']) . ' theme. Click \'Get this theme\' for more info."><i><span class="dashicons dashicons-star-filled"></span></i></div>';
    }
    echo '</div>';
  } // foreach theme
?>
      </div>
		</div>
</div><!-- #themes -->
