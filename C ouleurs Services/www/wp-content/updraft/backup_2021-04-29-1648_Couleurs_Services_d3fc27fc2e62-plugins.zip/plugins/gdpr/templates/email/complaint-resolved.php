<?php

echo esc_html__(
'We resolved your complaint request.
If you have any problems or questions, don\'t hesitate to contact us.', 'gdpr' );
